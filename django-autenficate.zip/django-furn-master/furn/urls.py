from django.urls import path, include 
from .views import *
from django.contrib.auth.views import LoginView

app_name = 'furn'

urlpatterns = [
    path('', home, name="home"),
    path('signup', signup, name='signup'),
    path('<int:pk>/details/', arrivals_detail, name='arrival_detail',),
    path("accounts/", include("django.contrib.auth.urls")),
    path('login/', LoginView.as_view(), name='login'),
    path('logout/', logout, name='logout-page')
]
